clear all; close all; clc;

M = fixedTTrankfactory([5 5 5], [1 5 5 1]);

checkmanifold(M);
