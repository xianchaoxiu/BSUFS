This is a modified version of the original package TTeMPS_1.1,
original authored by Michael Steinlechner. Please see LICENSE.txt in the
same directory for information of the original author and license.

This version contains modifications in order to help some modules work
better with manopt.

Link to original package: https://www.epfl.ch/labs/anchp/index-html/software/ttemps/

Modifications author: Michael Psenka, Nov. 24, 2020.
Modifications contributors: Nicolas Boumal.